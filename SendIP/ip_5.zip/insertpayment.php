       <?php
  
        // servername => localhost
        // username => root
        // password => empty
        // database name => staff
        include("connect_mysql.php");
          
        // Taking all 5 values from the form data(input)
        $bankname = $_REQUEST['bankname'];
        $bankno =$_REQUEST['bankno'];
        $accname = $_REQUEST['accname'];

          
        $sql = "INSERT INTO payment (Mobilebanking_BankName, Mobilebanking_AccID, Mobilebanking_Accname) VALUES ('$bankname', 
            '$bankno','$accname')";
          
        if(mysqli_query($conn, $sql)){
            echo "<script>location.href='payment.php';alert('Add Payment');</script>";
            
        } else{
            echo "ERROR: Hush! Sorry $sql. " 
                . mysqli_error($conn);
                Header("Location: login.php");
        }
 
          
        // Close connection
        mysqli_close($conn);
        ?>  