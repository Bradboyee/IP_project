<?php
  

  include("connect_mysql.php");
    
  $tel =$_REQUEST['tel'];
  $password =$_REQUEST['password'];
  $status = $_REQUEST['check'];

  if(empty($tel) || empty($password)){
    echo "<script>location.href='login.php';alert('กรุณากรอกข้อมูลให้ครบ');</script>";
    }

    else {

  if($status == "driver"){//driver login
  
    $select = mysqli_query($conn, "SELECT * FROM driver WHERE Driver_Tel = '".$_POST['tel']."' and Driver_Password = '".$_POST['password']."'" );

    
    if(mysqli_num_rows($select)==1){
        echo "<script>location.href='vaccine.php';alert('Login Success');</script>";
    }

    else{
        echo "<script>location.href='login.php';alert('Wrong Password Driver');</script>";
        }
  }
    else{//Custumer login
      
    $select = mysqli_query($conn, "SELECT * FROM customer WHERE Customer_tel = '".$_POST['tel']."' and Customer_Password = '".$_POST['password']."'" );

    
    if(mysqli_num_rows($select)==1){
        echo "<script>location.href='payment.php';alert('login Success');</script>";
    }

    else{
        echo "<script>location.href='login.php';alert('Wrong Password User');</script>";
        }
  }


}
    
  // Close connection
  mysqli_close($conn);
  ?>