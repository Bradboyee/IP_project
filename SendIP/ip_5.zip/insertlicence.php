<?php

  include("connect_mysql.php");

//licence
$LicenceIssueDate=$_REQUEST['LicenceIssueDate'];
$LicenceExpiryDate=$_REQUEST['LicenceExpiryDate'];
$LicenceLicencePlate=$_REQUEST['LicenceLicencePlate'];



$sql = "INSERT INTO licence (Licence_IssueDate, Licence_ExpiryDate, Licence_LicencePlate) VALUES ('$LicenceIssueDate', 
    '$LicenceExpiryDate','$LicenceLicencePlate')";
    
  if(mysqli_query($conn, $sql)){
      echo "<script>location.href='licence.php';alert('Add Licence');</script>";
      
  } else{
      echo "ERROR: Hush! Sorry $sql. " 
          . mysqli_error($conn);
  }

    
  // Close connection
  mysqli_close($conn);
  ?>  