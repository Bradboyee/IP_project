<?php

  include("connect_mysql.php");
    

//ATK
$ATKDetectPlace=$_REQUEST['ATKDetectPlace'];
$ATKDetectDate=$_REQUEST['ATKDetectDate'];
$ATKInfectedHistory=$_REQUEST['ATKInfectedHistory'];
$ATKDetectResult=$_REQUEST['ATKDetectResult'];


//ATK
$sql = "INSERT INTO atk (ATK_DetectPlace, ATK_DetectDate, ATK_InfectedHistory,ATK_DetectResult) VALUES ('$ATKDetectPlace', 
    '$ATKDetectDate','$ATKInfectedHistory','$ATKDetectResult')";

    
  if(mysqli_query($conn, $sql)){
      echo "<script>location.href='atk.php';alert('Add ATK');</script>";
      
  } else{
      echo "ERROR: Hush! Sorry $sql. " 
          . mysqli_error($conn);
  }

    
  // Close connection
  mysqli_close($conn);
  ?>  